const express = require("express");

const app = express();

app.use(express.json());
app.use(express.static("public"));

const users = [
    {
        username: "EmilioVega",
        password: "12345"
    },
    {
        username: "JosueGittens",
        password: "12345"
    },
    {
        username: "MiguelRios",
        password: "12345"
    }
];

let failedAttempts = 0;
let blockedUntil = null;

app.post("/login", (req, res) => {

    const { username, password } = req.body;

    const now = Date.now();

    if (blockedUntil && now < blockedUntil) {

        const remaining = Math.ceil(
            (blockedUntil - now) / 1000
        );

        return res.status(403).json({
            message: `Cuenta bloqueada. Espere ${remaining} segundos.`
        });
    }

    const userFound = users.find(
    user =>
        user.username === username &&
        user.password === password
);

if (userFound) {

        failedAttempts = 0;

        return res.json({
            success: true,
    message: "Acceso concedido.",
    user: userFound.username
        });
    }

    failedAttempts++;

    if (failedAttempts >= 5) {

        blockedUntil = Date.now() + 60000;

        failedAttempts = 0;

        return res.status(403).json({
            message: "Demasiados intentos. Cuenta bloqueada por 1 minuto."
        });
    }

    return res.status(401).json({
        message: `Credenciales incorrectas (${failedAttempts}/5)`
    });
});

app.listen(3000, () => {
 console.log("Servidor ejecutándose en http://localhost:3000");
});