# SecureLogin

## Descripción

SecureLogin es una aplicación web desarrollada para demostrar cómo prevenir ataques de fuerza bruta en sistemas de autenticación.

El sistema permite el inicio de sesión de usuarios autorizados y bloquea temporalmente el acceso después de varios intentos fallidos.

## Tecnologías Utilizadas

* Node.js
* Express.js
* HTML5
* CSS3
* JavaScript

## Características

* Inicio de sesión de usuarios.
* Protección contra ataques de fuerza bruta.
* Bloqueo automático después de 5 intentos fallidos.
* Dashboard de acceso para usuarios autenticados.
* Interfaz moderna y responsiva.

## Instalación

1. Clonar el repositorio:

```bash
git clone URL_DEL_REPOSITORIO
```

2. Entrar al proyecto:

```bash
cd fuerza-bruta-demo
```

3. Instalar dependencias:

```bash
npm install
```

## Ejecución

```bash
node server.js
```

Abrir en el navegador:

```text
http://localhost:3000
```

## Usuarios de Prueba

| Usuario     | Contraseña |
| ----------- | ---------- |
| Emilio      | 12345      |
| JosueGittens | 12345      |
| MiguelRios | 12345      |

## Seguridad Implementada

El sistema registra los intentos fallidos de autenticación.

Después de 5 intentos incorrectos consecutivos, la cuenta queda bloqueada temporalmente para prevenir ataques de fuerza bruta.

## Integrantes

* Emilio Vega
* Josue Gittens
* Miguel Rios

## Materia

Programacion Web 2