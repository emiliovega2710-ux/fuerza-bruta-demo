async function login() {

    const username =
        document.getElementById("username").value;

    const password =
        document.getElementById("password").value;

    const response = await fetch("/login", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            username,
            password
        })
    });

    const data = await response.json();

    const messageBox =
        document.getElementById("message");

    messageBox.style.display = "block";

    if(data.success){

        messageBox.className =
            "message-box success";

        messageBox.innerText =
            "✓ Acceso concedido";

        setTimeout(() => {

            localStorage.setItem(
                "username",
                data.user
            );

            window.location.href =
                "/dashboard.html";

        }, 1000);

    }else{

        if(data.message.includes("bloqueada")){

            messageBox.className =
                "message-box warning";

        }else{

            messageBox.className =
                "message-box error";

        }

        messageBox.innerText =
            data.message;
    }
}